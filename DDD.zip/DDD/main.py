import sys
import os

# Pega o caminho absoluto da pasta DDD
caminho_projeto = os.path.abspath(os.getcwd())
if caminho_projeto not in sys.path:
    sys.path.append(caminho_projeto)

# Agora os imports devem funcionar
from katalog.domain.factories import MidiaFactory
from katalog.domain.services import CatalogService